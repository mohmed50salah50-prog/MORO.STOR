Moro Store - Android project
1) Install Android Studio and open this folder (File > Open).
2) Wait for Gradle sync to finish.
3) Build > Build Bundle(s) / APK(s) > Build APK(s).
The APK appears in app/build/outputs/apk/debug/.
To edit prices/games: app/src/main/assets/index.html (top of the script).
